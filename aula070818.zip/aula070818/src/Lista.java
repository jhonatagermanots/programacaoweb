public class Lista {

    private No inicio;

    //Criar a lista
    public Lista() {
        this.inicio = null;
    }

    //Verifica se a lista esta vazia
    public boolean isVazia() {
        return this.inicio == null;
    }

    public void InserirInicio(No no) {
        if (isVazia()) {
            this.inicio = no;
        } else {
            no.setProximo(this.inicio);
            this.inicio = no;
        }
    }

    public void Imprimir() {
        if (isVazia()) {
            System.out.println("Lista vazia");
        } else {
            No aux = inicio;
            while (aux != null) {
                System.out.println(aux.getElemento());
                aux=aux.getProximo();

            }
        }
    }
    public void InserirFim(No no){
        if (isVazia()) {
            this.inicio = no;
        } else {
            No aux =this.inicio;
            while (aux!=null){
                aux= aux.getProximo();
            }
            aux.setProximo(no);
        }

    }



}