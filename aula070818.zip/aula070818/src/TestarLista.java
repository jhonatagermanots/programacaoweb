public class TestarLista {
    public static void main(String[] args) {

        Lista lista = new Lista();

        lista.Imprimir();

        lista.InserirInicio(new No(10));
        lista.InserirInicio(new No(11));
        lista.InserirInicio(new No(12));
        lista.InserirInicio(new No(13));
        lista.InserirInicio(new No(14));
        lista.InserirInicio(new No(15));
        lista.InserirInicio(new No(16));
        lista.InserirInicio(new No(17));
        lista.InserirInicio(new No(18));
        lista.InserirInicio(new No(19));
        lista.InserirInicio(new No(20));

        lista.Imprimir();
    }
}
